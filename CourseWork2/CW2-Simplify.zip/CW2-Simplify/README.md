## Useful cabal commands

- Update package list: `cabal update`
- Compile Simplify.hs and tests: `cabal build`
- Run tests: `cabal test`
- Open Simplify.hs in GHCi: `cabal repl`
